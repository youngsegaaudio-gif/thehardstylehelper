HARDSTYLE
=========

Unzip. Open HARDSTYLE.html in Safari.

Pick an artist (AR Gang, Lil Texas, Rebelion…).
Anthem / DJ tool / Collab = the map.
Save Logic template = a text file, no MIDI.

In Logic:
1. New empty project, set BPM from the template.
2. Create the empty tracks listed (no regions).
3. Arrangement track: marker at each bar number.
4. File → Save as Template.

This is not a Logic Audio Unit. Leave HARDSTYLE next to Logic.
Maps follow the AR Gang / Lil Texas 16/32 grid used across that school.
