BARLINE
=======

Unzip. Open BARLINE.html in Safari (double-click).

SONG — the upload button. Pick the bounce/wav. BARLINE plays it and the bar follows.

MIC — listens to Logic through your speakers. Allow microphone. Match BPM to the track first.

No Scripter. No mapping.
