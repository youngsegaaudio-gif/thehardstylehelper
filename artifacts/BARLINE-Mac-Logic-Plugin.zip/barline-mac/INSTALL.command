#!/bin/bash
cd "$(dirname "$0")"
DEST="$HOME/Music/Audio Music Apps/Plug-In Settings/Scripter"
mkdir -p "$DEST"
cp -f "Plug-in/BARLINE-Scripter.js" "$DEST/BARLINE-Scripter.js"
cp -f "Plug-in/BARLINE-Scripter.js" "$HOME/Desktop/BARLINE-Scripter.js" 2>/dev/null || true
open -a TextEdit "INSTALL-MAC.txt" 2>/dev/null || open "INSTALL-MAC.txt"
osascript -e 'display dialog "BARLINE copied.

Logic:
1. New Software Instrument
2. MIDI FX → Scripter
3. Open Script Editor
4. Paste Desktop/BARLINE-Scripter.js
5. Run Script
6. Save as BARLINE

Map extra PVC to C1." buttons {"OK"} default button 1 with title "BARLINE Mac plug-in"'
