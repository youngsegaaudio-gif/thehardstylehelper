// BARLINE — Logic Pro MIDI FX plug-in (Mac)
// Extra PVC kicks + 16-bar transitions
// Hardstyle / hard techno / rawstyle / UK hardcore
//
// INSTALL
// 1. Software Instrument track. Sampler or Drum Machine Designer.
//      C1  (36) extra / Peak PVC
//      C#1 (37) Impact PVC
//      D1  (38) Fill PVC
//      C#2 (49) crash
// 2. MIDI FX → Scripter → Open Script Editor
// 3. Paste this file → Run Script → Save as "BARLINE"
// 4. Play.

var NeedsTimingInfo = true;
var lastBar = -1;

function hit(pitch, vel, startBeat, lengthBeats) {
  var n = new NoteOn;
  n.pitch = pitch;
  n.velocity = vel;
  n.sendAtBeat(startBeat);
  var off = new NoteOff;
  off.pitch = pitch;
  off.sendAtBeat(startBeat + lengthBeats);
}

function ProcessMIDI() {
  var info = GetTimingInfo();
  if (!info.playing) {
    lastBar = -1;
    return;
  }
  var beat = info.blockStartBeat;
  var bar = Math.floor((beat - 1) / 4) + 1;
  if (bar === lastBar) return;
  lastBar = bar;

  var barStart = (bar - 1) * 4 + 1;
  var phraseEnd = (bar % 16 === 0);
  var phraseStart = (bar % 16 === 1 && bar > 1);

  // Bar 1 of a new 16: impact + crash
  if (phraseStart) {
    hit(37, 120, barStart, 0.5);
    hit(49, 100, barStart, 1.0);
  }

  // Last 2 bars of a 16: fill PVC roll + extra kick pickup
  if (phraseEnd) {
    hit(38, 108, barStart + 2, 0.2);
    hit(38, 112, barStart + 2.5, 0.2);
    hit(38, 116, barStart + 3, 0.15);
    hit(38, 118, barStart + 3.5, 0.15);
    hit(36, 110, barStart + 3.75, 0.2);
  }
}

function HandleMIDI(e) {
  e.send();
}
