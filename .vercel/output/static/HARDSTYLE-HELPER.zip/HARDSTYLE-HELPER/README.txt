HARDSTYLE HELPER

Open HELPER.html in Safari. Leave it next to Logic.
Not an Audio Unit.
Kick 3, Serum, FabFilter, Kilohearts, iZotope, Logic.
