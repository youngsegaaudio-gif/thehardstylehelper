BARLINE
=======

Unzip. Open BARLINE.html in Safari (double-click).

Upload a bounce to follow bars. Mic listens to the room.
Pick a hard-dance style. Speakers = pan + monitor triangle.

No Scripter. Not a Logic Audio Unit.
Leave the window next to Logic.
