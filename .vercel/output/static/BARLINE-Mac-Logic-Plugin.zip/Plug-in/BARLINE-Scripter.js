// BARLINE — Logic Pro MIDI FX plug-in (Mac)
// Style pack: hardstyle / hard techno / rawstyle extra PVC
//
// INSTALL
// 1. New Software Instrument track.
// 2. Sampler or Drum Machine Designer:
//      C1  (36)  extra / Peak PVC
//      C#1 (37)  Impact PVC
//      D1  (38)  Fill PVC
//      C#2 (49)  crash
// 3. MIDI FX → Scripter → Open Script Editor
// 4. Paste this whole file → Run Script
// 5. Play. Extra kicks fire at every 16-bar edge.

var NeedsTimingInfo = true;
var lastBar = -1;

function contains(arr, n) {
  for (var i = 0; i < arr.length; i++) if (arr[i] === n) return true;
  return false;
}

function hit(pitch, vel, startBeat, lengthBeats) {
  var n = new NoteOn;
  n.pitch = pitch;
  n.velocity = vel;
  n.sendAtBeat(startBeat);
  var off = new NoteOff;
  off.pitch = pitch;
  off.sendAtBeat(startBeat + lengthBeats);
}

function ProcessMIDI() {
  var info = GetTimingInfo();
  if (!info.playing) {
    lastBar = -1;
    return;
  }
  var beat = info.blockStartBeat;
  var bar = Math.floor((beat - 1) / 4) + 1;
  if (bar === lastBar) return;
  lastBar = bar;

  var barStart = (bar - 1) * 4 + 1;
  var phraseEnd = (bar % 16 === 0);
  var phraseStart = (bar % 16 === 1 && bar > 1);

  if (phraseStart) {
    hit(37, 120, barStart, 0.5);
    hit(49, 100, barStart, 1.0);
  }
  if (phraseEnd) {
    hit(38, 108, barStart + 2, 0.2);
    hit(38, 112, barStart + 2.5, 0.2);
    hit(38, 116, barStart + 3, 0.15);
    hit(38, 118, barStart + 3.5, 0.15);
    hit(36, 110, barStart + 3.75, 0.2);
  }
}

function HandleMIDI(e) {
  e.send();
}
