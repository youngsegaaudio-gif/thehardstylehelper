BARLINE for Logic Pro on Mac
=============================

This is a Logic MIDI FX plug-in (Scripter), not an Audio Unit.
Logic cannot load a website as an insert. Scripter is the plug-in.

INSTALL (2 minutes)
-------------------
1. Unzip this folder.
2. Open Logic. New Software Instrument.
3. Load Sampler or Drum Machine Designer.
   Put your extra PVC / click on C1 (note 36).
   Impact on C#1. Fill on D1. Crash on C#2.
4. On that track: MIDI FX → Scripter.
5. Open Script Editor. Paste Plug-in/BARLINE-Scripter.js
6. Click Run Script.
7. Play the song. Extra kicks fire at every 16-bar edge.

WHERE TO PUT TRANSITIONS
------------------------
Hardstyle / rawstyle
  Last 2 bars of each 16: snare roll or reverse.
  Bar 1 of the drop: crash + extra kick.
  Mute kick 1 bar before a switch, only once.

Hard techno
  Extra PVC on the offbeat of the last bar of a 16.
  Crash + impact on bar 1 of a peak.
  Filter break: pull the extra click, leave the body.

UK hardcore / happy
  Piano or vocal pickup on the last 4 of the break.
  Clap stack into the drop, extra kick on 1.

PVC extras (short)
------------------
Peak PVC     — the kick. Every beat of groove and peak.
Click extra  — 20–40 ms, HP 2 kHz, 6–8 dB under the peak.
Sub extra    — sine 45–60 Hz, peaks only.
Fill PVC     — last 2 bars of a 16, not the whole drop.
Ghost PVC    — −12 dB, hats-only sections.

Files
-----
Plug-in/BARLINE-Scripter.js   ← paste this
INSTALL.txt
pvc-kicks.txt
transitions.txt
